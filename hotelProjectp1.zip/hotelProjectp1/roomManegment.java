package hotelProjectp1;

import java.util.Scanner;

public class roomManegment {
	private static Room[] rooms;
	// i initialised an array that holds 50 rooms
	public roomManegment() {
		rooms = new Room[50];
		for(int i=0; i<50;i++) {
			int RoomNumber = 0 ; // those are to seperate the room numberss to each floor
			int FloorNumber = 0;
			if(i <10) {
				RoomNumber= 101 + i;
				FloorNumber = 1;
			} else if (i <20) {
				RoomNumber=201 + i -10;
				FloorNumber=2;
			}else if(i<30 ) {
				RoomNumber =301 + i -30;
				FloorNumber =3;
			}else if(i<40 ) {
				RoomNumber =401 + i - 40;
				FloorNumber = 4;
			}else if(i<50 ) {
			    RoomNumber =501 + i - 50;
				FloorNumber = 5;
			}
			String roomType = null;    // those are to seperate the room types 
			if(i <= 20) {
				roomType = "Standard";
			}else if(i <= 40) {
				roomType = "Family";
			}else if(i <= 50) {
				roomType= "Suit";
			}
			rooms[i] = new Room(RoomNumber , FloorNumber, roomType, false , 2, 100.0);
		}
	}
	// a method to show all the rooms by a for loop that iterates through the array
	// and prints each one of them and the to string method is to get the actual values
	//of the room and not its address
	public static void showAllRooms() {
		System.out.println("Here are all the rooms: \n");
		for(int i=0; i<rooms.length;i++) {
			System.out.println(rooms[i].tostring());
			
		}
	}
	// a method that shows the rooms that are not occupied by checking the boolean value
	// so if the boolean is occupied is true then it is not available
	public static void showAvailableRooms() {
		System.out.println("Here is all the available rooms:");
		for(Room room :rooms ) {
			if(!room.getisOccupied()) {
				System.out.println(room.tostring());
			}
		}
	}//a method to change the room details by using a scanner and a switch case statement
	public static void changeRoomDetails() {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter the room number you would like to change details");
		int RoomNumber = input.nextInt();
		Room room = FindRoomByNumber(RoomNumber);
		
			System.out.println("Select the detail you would like to change");
			System.out.println(" 1- Change Room type");
			System.out.println(" 2- Check in/out (change occupancy status)");
			System.out.println(" 3- Change the capacity of the room");
			System.out.println(" 4- Price per night");
			int option = input.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter the new room type: ");
				String NewroomType =input.next();
				room.setRoomType(NewroomType);
				System.out.println("Your new room type is: "+NewroomType);
				break;
				
			case 2:
				System.out.println("Enter (true) to check in or (false)to check out");
				boolean NewresStatus = input.nextBoolean();
				room.setisOccupied(NewresStatus);
				if(NewresStatus == true) {
					System.out.println("Your check in is completed");
				}else if(NewresStatus == false) {
					System.out.println("Your check out is completed ,Thanks for choosing our hotel");
				}
				break;
			case 3:
				System.out.println("Enter the new capacity");
				int newCapacity = input.nextInt();
				room.setCapacity(newCapacity);
				System.out.println("Your new capacity is: "+newCapacity);
				break;
			case 4:
				System.out.println("Enter new price per night: ");
				double newPrice = input.nextDouble();
				room.setPricePerNight(newPrice);
				System.out.println("Your new price per night is: "+newPrice);
				break;
				default:
					System.out.println("Invalid , your chioce is not on the list");
			}
		}
		// a method to search for a room by a certain type whether its standard family or suit
	
	public static void SearchByRoomType(String RoomType) {
		System.out.println("The rooms by type are:"+RoomType +(RoomType));
		for (Room room :rooms) {
			if(room.getRoomType().equalsIgnoreCase(RoomType)) {
				System.out.println(room.tostring());
			}
		}
	}// a method that searches for a room with a certain capacity by a for each loop 
	public static void SearchByCapacity(int Capacity) {
		System.out.println("The rooms by capacity = "+Capacity+"are:");
		boolean exist = false;
		for (Room room : rooms) {
			if(room.getCapacity()==Capacity) {
				System.out.println(room.tostring());
				exist=true;
			}
		}
		if(!exist) {
			System.out.println("No such room exist");
		}
	}
// a method that searches for a room by its number by a loop iterating through the array
	private static Room FindRoomByNumber(int RoomNumber) {
		
		for(int i=0; i<rooms.length; i++) {
			System.out.println(RoomNumber);
			
			
			
		}return null;
	}

}


