package hotelProjectp1;

public class Room {
	private int RoomNumber;
	private int FloorNumber;
	private String RoomType= "Standard,Family,Suit";
	private Boolean isOccupied;
	private int Capacity;
	private Double PricePerNight;
	
	public   Room(int RoomNumber,int FloorNumber,String RoomType,Boolean isOccupied,int Capacity,Double PricePerNight){
		this.setRoomNumber(RoomNumber);
		this.setFloorNumber(FloorNumber);
		this.setRoomType(RoomType);
		this.setisOccupied(isOccupied);
		this.setCapacity(Capacity);
		this.setPricePerNight(PricePerNight);	
	}
	
	public int getRoomNumber(){   // here are all the getters
		return RoomNumber;
	}
	public int getFloorNumber(){
		return FloorNumber;
	}
	public String getRoomType(){
		return RoomType;
	}
	public Boolean getisOccupied(){
		return isOccupied;
	}
	public int getCapacity(){
		return Capacity;
	}
	public Double getPricePerNight(){
		return PricePerNight;
	}
	// here are all the setters
	public void setRoomNumber(int RoomNumber){
		this.RoomNumber=RoomNumber;
		
	}
	public void setFloorNumber(int FloorNumber){
		this.FloorNumber=FloorNumber;
	}
	public void setRoomType(String RoomType){
		this.RoomType=RoomType;
	}
	public void setisOccupied(Boolean isOccupied){
		this.isOccupied=isOccupied;
	}
	public void setCapacity(int Capacity){
		this.Capacity=Capacity;
	}
	public void setPricePerNight(Double PricePerNight){
		this.PricePerNight=PricePerNight;
	}
	// a to string method to use later in the roommanegment object
	public String tostring(){
		return "Rooms: " +
	           ",Room number: "+ RoomNumber +
	           ",Floor number: "+ FloorNumber+
	           ",Room Type: "+ RoomType +
	           ",Is it Occupied:"+ isOccupied +
	           ", Capacity: " + Capacity +
	           ",Price Per night" + PricePerNight;
	           
	}
	// and here are methods to check if the values are acceptable or not
	public static boolean isRoomNumberacceptable(int RoomNumber) {
		return RoomNumber >= 101 && RoomNumber <= 510;   
	}
	public static boolean isRoomTypeacceptable(String RoomType) {
		return RoomType.equals("Standard") || RoomType.equals("family")|| RoomType.equals("suit");
				
	}
	public static boolean isCapacityacceptable(int Capacity) {
		return Capacity >=1 && Capacity <=10;
	}

}
