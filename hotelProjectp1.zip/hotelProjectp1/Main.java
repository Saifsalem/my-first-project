package hotelProjectp1;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		roomManegment Roommanegment = new roomManegment();
		//here i initialized the scanner
		Scanner input = new Scanner(System.in);
		String option;
		System.out.println("Welcome to our hotel");
		//a do while loop with a scanner to represent the main menu
		do {			
		System.out.println("Choose the option you like");
		System.out.println("a- Show all rooms");
		System.out.println("b- Show availabe rooms");
		System.out.println("c- Change room details");
		System.out.println("d- Search by room type ");
		System.out.println("e- Search by capacity");
		System.out.println("f- Quit");
		 option=input.next();
				
		//a switch case series for the options in the main menu
			// all the methods that has been called in the switch case are made in an object 
		 //called room manegment
			switch (option) {
			case "a":
				roomManegment.showAllRooms();
				break;
			case "b":
				roomManegment.showAvailableRooms();
				break;
			case "c":
				roomManegment.changeRoomDetails();
				break;
			case "d":
				System.out.println("Which room type are you looking for?");
				String type=input.next();
				roomManegment.SearchByRoomType(type);
				break;
			case "e":
				System.out.println("How much capacity are you looking for");
				int capa=input.nextInt();
				roomManegment.SearchByCapacity(capa);
				break;
			case "f":
				System.out.println("Thanks for choosing us");
				break;
				default:
					System.out.println("Invalid,thats not an option");
			}	
			}while(option !="f");
		
		}
	



	}


